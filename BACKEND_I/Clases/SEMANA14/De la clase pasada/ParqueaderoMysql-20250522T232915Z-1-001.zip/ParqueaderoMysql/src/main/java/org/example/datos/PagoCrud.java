package org.example.datos;

public class PagoCrud {
}

package org.example.datos;

public class PropietarioCrud {
}

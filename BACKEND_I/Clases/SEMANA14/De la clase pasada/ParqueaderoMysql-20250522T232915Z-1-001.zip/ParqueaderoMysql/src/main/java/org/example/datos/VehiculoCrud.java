package org.example.datos;

public class VehiculoCrud {

}
